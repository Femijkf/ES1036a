public class Task2 {
    public static void main(String[] args) {
        // this is ascii art for word "JAVA"
        System.out.println("   *    *    *     *    *");
        System.out.println("   *   * *    *   *    * * ");
        System.out.println("*  *  *****    * *    *****");
        System.out.println(" **  *     *    *    *     *");
    }
}
