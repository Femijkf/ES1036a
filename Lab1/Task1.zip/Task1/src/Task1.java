public class Task1 {
    // We want to create the program starting point
    // So we will create the main method
    public static void main(String[] args) {
        // This statement prints a welcome message
        System.out.println("Welcome to ES1036a course!");
    }
}