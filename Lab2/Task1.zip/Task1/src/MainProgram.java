// The restriction: the class should have the name MainProgram
public class MainProgram {
//    The start point of your program
    public static void main(String[] args) {
        System.out.println("It's compiled!"); // It prints "It's compiled!"
    }
}