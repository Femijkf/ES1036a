public class Task2 {
    public static void main(String[] args) {
        // string variable that stores my full name as a value
        String name = "Femi Odujinrin";
        // int variable that stores my age as a value
        int age = 18;
        // double variable that stores my desired annual pay as a value
        double annualPay = 3141592.65;
        // prints out the requested final concatenated statement including all variables and added string sentences
        System.out.println("My name is " + name + ", my age is " + age + " and \nI hope to earn $" + annualPay + " per year.");
    }
}