public class Cat extends Animal {

    // say() method that overrides say() method from Animal
    @Override
    public String say() {
        return "meow-meow";
    }
}
