public class Animal {
// method say returning an empty string
    public String say() {
        return "";
    }
}
