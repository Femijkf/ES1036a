public class Duck extends Animal{
    // say() method that overrides say() method from Animal
    @Override
    public String say() {
        return "quack-quack";
    }
}
