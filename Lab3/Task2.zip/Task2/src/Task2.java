import java.util.Scanner;

public class Task2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int n;

        n = input.nextInt();
        // mathematical equation that is printed out
        System.out.println(((n+1) * n+2) * n+3);

    }
}
